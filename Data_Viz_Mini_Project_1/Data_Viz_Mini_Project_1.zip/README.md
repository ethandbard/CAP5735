Data Visualization Mini Project 1
Ethan Bard
10/10/21

This project is my submission for Data Visualization Mini Project 1 for CAP575. 

In the *report* folder, two .Rmd files are present.

- **report.Rmd**
- fuel_eda.Rmd

**report.Rmd** contains my write up along with all important visualizations. **fuel_eda.Rmd** is the *orginal* .Rmd where I did all of the code and design. 
